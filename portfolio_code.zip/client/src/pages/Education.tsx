import { motion } from "framer-motion";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { useRef } from "react";
import { useInView } from "framer-motion";
import { useParallax } from "@/hooks/use-parallax";
import { Briefcase, Calendar, MapPin } from "lucide-react";

export default function Education() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: false });
  
  const { ref: headerRef, style: headerStyle } = useParallax({ 
    speed: 0.3, 
    direction: 'up'
  });
  
  const { ref: timelineRef, style: timelineStyle } = useParallax({ 
    speed: 0.2, 
    direction: 'up'
  });
  
  // Define timeline data
  const timeline = [
    {
      period: "2019 - Present",
      title: "Senior Frontend Developer",
      company: "Tech Innovations Inc.",
      location: "San Francisco, CA",
      description: "Lead frontend developer for client projects in fintech and e-commerce. Implemented complex UI components and optimized web performance.",
      skills: ["React", "TypeScript", "Next.js", "GraphQL"]
    },
    {
      period: "2017 - 2019",
      title: "Web Developer",
      company: "Digital Solutions Agency",
      location: "Boston, MA",
      description: "Developed responsive websites and interactive applications for various clients. Collaborated with design team to implement pixel-perfect UIs.",
      skills: ["JavaScript", "Vue.js", "CSS/SCSS", "Webpack"]
    },
    {
      period: "2015 - 2017",
      title: "Junior Developer",
      company: "Startup Ventures",
      location: "Austin, TX",
      description: "Built and maintained company websites and internal tools. Assisted in the design and implementation of frontend features.",
      skills: ["HTML/CSS", "JavaScript", "jQuery", "Bootstrap"]
    },
    {
      period: "2013 - 2015",
      title: "BSc Computer Science",
      company: "University of Technology",
      location: "Chicago, IL",
      description: "Graduated with honors. Specialized in web technologies and software engineering. Completed several personal and academic projects.",
      skills: ["Algorithms", "Data Structures", "Web Development", "Java"]
    }
  ];
  
  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        when: "beforeChildren",
        staggerChildren: 0.2
      }
    }
  };
  
  const itemVariants = {
    hidden: { y: 30, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.5 }
    }
  };

  return (
    <div className="font-sans bg-background dark:bg-background text-foreground dark:text-foreground transition-colors duration-500">
      <Navbar />
      
      <main>
        <section className="py-24 relative bg-gradient-to-b from-background to-background/95">
          <div className="absolute inset-0 bg-[url('/grid-pattern.svg')] bg-center opacity-5"></div>
          
          <div className="container mx-auto px-6 relative z-10">
            <motion.div 
              className="text-center mb-16"
              ref={headerRef}
              style={headerStyle}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <h1 className="text-4xl md:text-5xl font-bold font-display mb-4">
                My <span className="text-primary">Journey</span>
              </h1>
              <p className="max-w-2xl mx-auto opacity-80 text-lg">
                Professional experience and educational background that shaped my career path.
              </p>
            </motion.div>
            
            <motion.div 
              ref={timelineRef}
              style={timelineStyle}
              animate={inView ? "visible" : "hidden"}
              initial="hidden"
              variants={containerVariants}
              className="relative max-w-4xl mx-auto"
            >
              {/* Timeline center line */}
              <div className="absolute left-1/2 transform -translate-x-1/2 top-0 h-full w-px bg-primary/20 z-0"></div>
              
              {timeline.map((item, index) => (
                <motion.div 
                  key={index}
                  className={`flex items-center mb-16 relative ${index % 2 === 0 ? 'justify-start' : 'justify-end'}`}
                  variants={itemVariants}
                >
                  {/* Timeline dot */}
                  <div className="absolute left-1/2 transform -translate-x-1/2 w-4 h-4 bg-primary rounded-full z-10"></div>
                  
                  {/* Content card */}
                  <div className={`w-5/12 bg-white dark:bg-[#161616] p-6 rounded-lg shadow-lg relative ${index % 2 === 0 ? 'mr-auto' : 'ml-auto'}`}>
                    <div className="absolute top-1/2 transform -translate-y-1/2 w-4 h-4 -mt-px rotate-45 bg-white dark:bg-[#161616] ${index % 2 === 0 ? '-right-2' : '-left-2'}"></div>
                    
                    <div className="flex items-center mb-2 text-primary">
                      <Calendar className="w-4 h-4 mr-2" />
                      <span className="text-sm font-medium">{item.period}</span>
                    </div>
                    
                    <h3 className="text-xl font-bold mb-1">{item.title}</h3>
                    
                    <div className="flex items-center mb-3">
                      <Briefcase className="w-4 h-4 mr-2 opacity-60" />
                      <span className="text-sm opacity-70">{item.company}</span>
                      <span className="mx-2 opacity-40">|</span>
                      <MapPin className="w-4 h-4 mr-2 opacity-60" />
                      <span className="text-sm opacity-70">{item.location}</span>
                    </div>
                    
                    <p className="mb-4 text-sm">{item.description}</p>
                    
                    <div className="flex flex-wrap gap-2">
                      {item.skills.map((skill, i) => (
                        <span 
                          key={i} 
                          className="px-3 py-1 bg-primary/10 text-primary text-xs rounded-full"
                        >
                          {skill}
                        </span>
                      ))}
                    </div>
                  </div>
                </motion.div>
              ))}
            </motion.div>
            
            <motion.div 
              className="mt-20 text-center max-w-2xl mx-auto"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.8 }}
            >
              <h3 className="text-2xl font-semibold mb-4">Education & Certifications</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
                <div className="bg-white dark:bg-[#161616] p-6 rounded-lg shadow-md">
                  <h4 className="font-bold mb-2">BSc Computer Science</h4>
                  <p className="text-sm opacity-70 mb-2">University of Technology, 2013-2015</p>
                  <p className="text-sm">Graduated with first-class honors. Focused on web technologies and UI/UX design.</p>
                </div>
                
                <div className="bg-white dark:bg-[#161616] p-6 rounded-lg shadow-md">
                  <h4 className="font-bold mb-2">Frontend Development Certification</h4>
                  <p className="text-sm opacity-70 mb-2">Tech Institute, 2016</p>
                  <p className="text-sm">Advanced course in modern frontend development practices and frameworks.</p>
                </div>
              </div>
            </motion.div>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
}