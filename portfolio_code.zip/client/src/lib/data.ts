export interface Project {
  id: number;
  title: string;
  image: string;
  tags: string[];
  description: string;
  features: string[];
  repo: string;
  demo: string;
}

export const projects: Project[] = [
  {
    id: 1,
    title: "E-commerce Dashboard",
    image: "https://images.unsplash.com/photo-1551434678-e076c223a692?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80",
    tags: ["React", "Redux", "Tailwind CSS", "Chart.js"],
    description: "A comprehensive dashboard for e-commerce store owners with real-time sales analytics and inventory management.",
    features: [
      "Real-time sales tracking with filterable date ranges",
      "Inventory management with low stock alerts",
      "Customer insights with purchase behavior analysis",
      "Customizable dashboard widgets",
      "Mobile-responsive design for on-the-go management"
    ],
    repo: "https://github.com",
    demo: "https://example.com"
  },
  {
    id: 2,
    title: "Travel Companion App",
    image: "https://images.unsplash.com/photo-1558655146-d09347e92766?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80",
    tags: ["Next.js", "Google Maps API", "Tailwind CSS", "MongoDB"],
    description: "A travel planner with personalized recommendations, itinerary creation, and real-time information.",
    features: [
      "Interactive map with points of interest",
      "AI-powered trip recommendations based on preferences",
      "Itinerary builder with drag-and-drop interface",
      "Offline mode for saved itineraries",
      "Weather integration for trip planning"
    ],
    repo: "https://github.com",
    demo: "https://example.com"
  },
  {
    id: 3,
    title: "AI Content Generator",
    image: "https://images.unsplash.com/photo-1534972195531-d756b9bfa9f2?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80",
    tags: ["React", "Node.js", "OpenAI API", "Express", "MongoDB"],
    description: "An AI-powered application for generating marketing copy, blog posts, and social media content.",
    features: [
      "Multiple content types (blogs, ads, social posts)",
      "Tone and style customization",
      "Content editing with AI suggestions",
      "Export to multiple formats (MD, HTML, DOCX)",
      "Content history with version tracking"
    ],
    repo: "https://github.com",
    demo: "https://example.com"
  }
];
